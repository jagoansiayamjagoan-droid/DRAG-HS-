package com.echotex.draghs67

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Mode latihan lokal di dalam aplikasi. Seret jari untuk menggerakkan crosshair virtual;
 * sensitivitas menentukan seberapa jauh crosshair bergerak per jarak seretan.
 * Tidak berhubungan dengan Free Fire dan tidak mengubah pengaturan game apa pun.
 */
class TrainingActivity : Activity() {

    private lateinit var repo: SettingsRepository
    private lateinit var stats: TextView
    private lateinit var target: TargetView
    private lateinit var control: SensitivityControl
    private var streak = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SettingsRepository(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(16))
            setBackgroundResource(R.drawable.bg_gradient)
        }

        val title = Ui.label(this, "TRAINING", 24f, R.color.neon_cyan, true).apply {
            gravity = Gravity.CENTER
            Ui.neon(this, R.color.neon_cyan)
        }
        val hint = Ui.label(
            this,
            "Seret jari di area bawah untuk menggeser crosshair ke dalam lingkaran, lalu lepas untuk menembak (simulasi).",
            11f, R.color.text_dim
        ).apply { setPadding(0, dp(6), 0, dp(6)) }
        stats = Ui.label(this, "", 12f, R.color.text_primary)

        target = TargetView(this) { hit -> onResult(hit) }.apply {
            factor = factorFor(repo.sensitivity)
            minimumHeight = dp(180)
            layoutParams = LinearLayout.LayoutParams(Ui.MATCH, 0, 1f).apply {
                topMargin = dp(8)
                bottomMargin = dp(8)
            }
        }

        control = sensitivityControl(this, repo) { v ->
            target.factor = factorFor(v)
            refreshStats()
        }

        val reset = Ui.neonButton(this, "RESET", R.color.danger, 48).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) }
            setOnClickListener {
                repo.resetAll()
                streak = 0
                control.refresh()
                target.factor = factorFor(repo.sensitivity)
                refreshStats()
            }
        }
        val backBtn = Ui.neonButton(this, "KEMBALI", R.color.electric_blue, 48).apply {
            layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) }
            setOnClickListener { Ui.back(this@TrainingActivity) }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(reset)
            addView(backBtn)
        }

        root.addView(title)
        root.addView(hint)
        root.addView(stats)
        root.addView(target)
        root.addView(control.view)
        root.addView(buttons)
        setContentView(root)
        refreshStats()
    }

    private fun onResult(hit: Boolean) {
        repo.attempts += 1
        if (hit) {
            repo.hits += 1
            streak += 1
            if (streak > repo.bestStreak) repo.bestStreak = streak
        } else {
            streak = 0
        }
        refreshStats()
    }

    private fun refreshStats() {
        val attempts = repo.attempts
        val acc = if (attempts > 0) repo.hits * 100 / attempts else 0
        stats.text = "TEMBAKAN $attempts | KENA ${repo.hits} | AKURASI $acc%\n" +
            "STREAK $streak (terbaik ${repo.bestStreak}) | GERAK x${"%.2f".format(target.factor)}"
    }

    companion object {
        /** Pengali gerak crosshair: sensitivitas 0 -> 0.20, 67 -> 1.41, 100 -> 2.00. */
        fun factorFor(sensitivity: Int): Float = 0.2f + sensitivity.coerceIn(0, 100) * 0.018f
    }
}

class TargetView(ctx: Context, private val onResult: (Boolean) -> Unit) : View(ctx) {

    var factor = 1.4f

    private val cyan = ctx.getColor(R.color.neon_cyan)
    private val blue = ctx.getColor(R.color.electric_blue)
    private val green = ctx.getColor(R.color.ok_green)
    private val red = ctx.getColor(R.color.danger)

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(3).toFloat()
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(2).toFloat()
        color = Color.WHITE
    }
    private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(2).toFloat()
        color = blue
    }
    private val trail = Path()
    private val rnd = Random()

    private var tx = 0f
    private var ty = 0f
    private var radius = 0f
    private var cx = 0f
    private var cy = 0f
    private var downX = 0f
    private var downY = 0f
    private var baseX = 0f
    private var baseY = 0f
    private var dragging = false
    private var locked = false
    private var lastHit: Boolean? = null

    init {
        background = Ui.rounded(ctx, Color.argb(100, 0, 0, 0), blue)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        radius = min(w, h) * 0.11f
        newRound()
    }

    private fun newRound() {
        if (width == 0 || height == 0) return
        cx = width / 2f
        cy = height / 2f
        var tries = 0
        do {
            tx = radius + rnd.nextFloat() * max(1f, width - 2 * radius)
            ty = radius + rnd.nextFloat() * max(1f, height - 2 * radius)
            tries++
        } while (hypot(tx - cx, ty - cy) < radius * 2f && tries < 20)
        trail.reset()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val c = when (lastHit) {
            true -> green
            false -> red
            null -> cyan
        }
        fillPaint.color = Color.argb(50, Color.red(c), Color.green(c), Color.blue(c))
        ringPaint.color = c
        canvas.drawCircle(tx, ty, radius, fillPaint)
        canvas.drawCircle(tx, ty, radius, ringPaint)
        canvas.drawCircle(tx, ty, radius * 0.5f, ringPaint)

        canvas.drawPath(trail, trailPaint)

        val arm = radius * 0.6f
        canvas.drawLine(cx - arm, cy, cx + arm, cy, crossPaint)
        canvas.drawLine(cx, cy - arm, cx, cy + arm, crossPaint)
        canvas.drawCircle(cx, cy, arm * 0.35f, crossPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (locked) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                downX = e.x
                downY = e.y
                baseX = cx
                baseY = cy
                trail.reset()
                trail.moveTo(cx, cy)
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    cx = (baseX + (e.x - downX) * factor).coerceIn(0f, width.toFloat())
                    cy = (baseY + (e.y - downY) * factor).coerceIn(0f, height.toFloat())
                    trail.lineTo(cx, cy)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    dragging = false
                    finishShot()
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                newRound()
            }
        }
        return true
    }

    private fun finishShot() {
        val hit = hypot(cx - tx, cy - ty) <= radius
        lastHit = hit
        locked = true
        invalidate()
        onResult(hit)
        postDelayed({
            locked = false
            lastHit = null
            newRound()
        }, 400)
    }
}
