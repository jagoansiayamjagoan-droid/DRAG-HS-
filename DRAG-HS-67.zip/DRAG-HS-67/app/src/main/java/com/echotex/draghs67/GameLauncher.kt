package com.echotex.draghs67

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Membuka Free Fire biasa lewat launch intent resmi. Tanpa root, tanpa API tersembunyi. */
object GameLauncher {

    const val PACKAGE_NAME = "com.dts.freefireth"

    sealed class Result {
        object Launched : Result()
        object NotInstalled : Result()
        object NoLaunchIntent : Result()
        data class Failed(val message: String) : Result()
    }

    @Suppress("DEPRECATION")
    fun isInstalled(context: Context): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= 33) {
                context.packageManager.getPackageInfo(
                    PACKAGE_NAME, PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                context.packageManager.getPackageInfo(PACKAGE_NAME, 0)
            }
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun launch(context: Context): Result {
        if (!isInstalled(context)) return Result.NotInstalled
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE_NAME)
            ?: return Result.NoLaunchIntent
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            Result.Launched
        } catch (e: ActivityNotFoundException) {
            Result.Failed(e.message ?: "Activity tidak ditemukan")
        } catch (e: SecurityException) {
            Result.Failed(e.message ?: "Akses ditolak sistem")
        }
    }
}
