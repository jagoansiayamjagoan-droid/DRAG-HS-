package com.echotex.draghs67

import android.content.Context

/** Penyimpanan lokal (SharedPreferences). Tidak ada data pribadi dan tidak ada jaringan. */
class SettingsRepository(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var sensitivity: Int
        get() = prefs.getInt(KEY_SENSITIVITY, DEFAULT_SENSITIVITY).coerceIn(0, 100)
        set(value) {
            prefs.edit().putInt(KEY_SENSITIVITY, value.coerceIn(0, 100)).apply()
        }

    var panelEnabled: Boolean
        get() = prefs.getBoolean(KEY_PANEL_ENABLED, true)
        set(value) {
            prefs.edit().putBoolean(KEY_PANEL_ENABLED, value).apply()
        }

    var attempts: Int
        get() = prefs.getInt(KEY_ATTEMPTS, 0)
        set(value) {
            prefs.edit().putInt(KEY_ATTEMPTS, value).apply()
        }

    var hits: Int
        get() = prefs.getInt(KEY_HITS, 0)
        set(value) {
            prefs.edit().putInt(KEY_HITS, value).apply()
        }

    var bestStreak: Int
        get() = prefs.getInt(KEY_BEST_STREAK, 0)
        set(value) {
            prefs.edit().putInt(KEY_BEST_STREAK, value).apply()
        }

    fun resetStats() {
        prefs.edit()
            .putInt(KEY_ATTEMPTS, 0)
            .putInt(KEY_HITS, 0)
            .putInt(KEY_BEST_STREAK, 0)
            .apply()
    }

    /** Mengembalikan semua pengaturan dan statistik ke nilai awal (sensitivitas 67%). */
    fun resetAll() {
        prefs.edit().clear().apply()
    }

    companion object {
        const val DEFAULT_SENSITIVITY = 67
        private const val PREFS_NAME = "draghs67_prefs"
        private const val KEY_SENSITIVITY = "sensitivity"
        private const val KEY_PANEL_ENABLED = "panel_enabled"
        private const val KEY_ATTEMPTS = "attempts"
        private const val KEY_HITS = "hits"
        private const val KEY_BEST_STREAK = "best_streak"
    }
}
