package com.echotex.draghs67

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.Toast

/**
 * Panel overlay kecil yang hanya menampilkan informasi dan kontrol milik aplikasi ini.
 * Tidak membaca layar/game, tidak menyuntikkan input, tidak memakai Accessibility Service.
 * Berjalan sebagai foreground service agar tidak dimatikan sistem saat app berada di latar belakang.
 */
class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
            private set

        const val ACTION_STOP = "com.echotex.draghs67.action.STOP"
        private const val CHANNEL_ID = "overlay_channel"
        private const val NOTIF_ID = 6701
    }

    private var wm: WindowManager? = null
    private var panel: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Settings.canDrawOverlays(this) || !SettingsRepository(this).panelEnabled) {
            Toast.makeText(this, "Izin overlay belum aktif atau panel dimatikan.", Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }
        if (panel == null) addPanel()
        running = panel != null
        return START_NOT_STICKY
    }

    private fun startAsForeground(): Boolean {
        return try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
            )
            val openPi = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val stopPi = PendingIntent.getService(
                this, 1,
                Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val stopAction = Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_notif),
                getString(R.string.notif_stop), stopPi
            ).build()
            val notification = Notification.Builder(this, CHANNEL_ID)
                .setContentTitle(getString(R.string.notif_title))
                .setContentText(getString(R.string.notif_text))
                .setSmallIcon(R.drawable.ic_notif)
                .setContentIntent(openPi)
                .addAction(stopAction)
                .setOngoing(true)
                .build()

            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(NOTIF_ID, notification)
            }
            true
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal memulai layanan: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun addPanel() {
        val manager = wm ?: return

        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(80)
        }

        val title = Ui.label(this, "DRAG HS 67%", 13f, R.color.neon_cyan, true)
            .apply { setPadding(dp(10), dp(6), dp(6), dp(6)) }

        val status = Ui.label(this, "● ON", 12f, R.color.ok_green, true).apply {
            setPadding(dp(8), dp(6), dp(8), dp(6))
            setOnClickListener {
                text = "● OFF"
                setTextColor(getColor(R.color.danger))
                stopSelf()
            }
        }

        val handle = Ui.label(this, "☰", 16f, R.color.electric_blue, true).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x
                    startY = p.y
                    touchX = e.rawX
                    touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (e.rawX - touchX).toInt()
                    p.y = startY + (e.rawY - touchY).toInt()
                    clampAndUpdate()
                }
            }
            true
        }

        val close = Ui.label(this, "×", 18f, R.color.danger, true).apply {
            setPadding(dp(10), dp(2), dp(10), dp(2))
            setOnClickListener { stopSelf() }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(this@OverlayService, getColor(R.color.panel_bg), getColor(R.color.neon_cyan), 12)
            addView(title)
            addView(status)
            addView(handle)
            addView(close)
        }

        try {
            manager.addView(bar, p)
            panel = bar
            params = p
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menampilkan overlay: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun clampAndUpdate() {
        val v = panel ?: return
        val p = params ?: return
        val dm = resources.displayMetrics
        p.x = p.x.coerceIn(0, maxOf(0, dm.widthPixels - v.width))
        p.y = p.y.coerceIn(0, maxOf(0, dm.heightPixels - v.height))
        try {
            wm?.updateViewLayout(v, p)
        } catch (e: IllegalArgumentException) {
            // View sudah dilepas; abaikan.
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        panel?.post { clampAndUpdate() }
    }

    override fun onDestroy() {
        running = false
        panel?.let {
            try {
                wm?.removeView(it)
            } catch (e: IllegalArgumentException) {
                // Sudah dilepas.
            }
        }
        panel = null
        params = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
